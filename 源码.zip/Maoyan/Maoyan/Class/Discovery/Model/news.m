//
//  news.m
//  demo1_新闻客户端
//
//  Created by tarena012 on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "news.h"

@implementation news
+(NSArray *)demoData
{
    news *n1 = [[news alloc]init];
    n1.newsImageName = @"n1.JPG";
    n1.title = @"这部你们期待很久的动画片，终于来了，看到泪崩！";
    n1.clickNumber = 97;
    n1.commentNumber = 76;
    n1.time = @"1小时以前";
    
    news *n2 = [[news alloc]init];
    n2.newsImageName = @"n2.JPG";
    n2.title = @"看过3月片单，我整个人都精神了";
    n2.clickNumber = 14;
    n2.commentNumber = 4;
    n2.time = @"2小时以前";
    
    
    news *n3 = [[news alloc]init];
    n3.newsImageName = @"n3.JPG";
    n3.title = @"今年颁奖季最红的男星并不是小李，而是他！";
    n3.clickNumber = 17;
    n3.commentNumber = 16;
    n3.time = @"2小时以前";
    
    news *n4 = [[news alloc]init];
    n4.newsImageName = @"n4.JPG";
    n4.title = @"莱奥，我很高兴可以亲自告诉你我有多么爱你";
    n4.clickNumber = 16;
    n4.commentNumber = 7;
    n4.time = @"3小时以前";
    
    news *n5 = [[news alloc]init];
    n5.newsImageName = @"n5.JPG";
    n5.title = @"看了一眼三月的电影，春天终于来了";
    n5.clickNumber = 31;
    n5.commentNumber = 5;
    n5.time = @"3小时以前";
    
    return @[n1,n2,n3,n4,n5];
}
@end
