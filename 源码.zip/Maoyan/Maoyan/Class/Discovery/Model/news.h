//
//  news.h
//  demo1_新闻客户端
//
//  Created by tarena012 on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface news : NSObject

@property(nonatomic,strong) NSString *newsImageName;
@property (nonatomic,strong)NSString *title;
@property(nonatomic) NSInteger commentNumber;
@property(nonatomic) NSInteger clickNumber;
@property(nonatomic) NSString *time;
+(NSArray *)demoData;
@end
