//
//  NewsCell.m
//  demo1_新闻客户端
//
//  Created by tarena012 on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "NewsCell.h"
@interface NewsCell()
@property (weak, nonatomic) IBOutlet UIImageView *newsImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *commentNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *clickNumberLabel;
@end
@implementation NewsCell

//一个news属性赋值，就将数据显示到控件上，这种一赋值就要做xxx得时机，可以通过重写setter方法实现
-(void)setNews:(news *)news
{
    _news = news;
    //显示news的各个数据到指定控件上
    self.newsImageView.image = [UIImage imageNamed:news.newsImageName];
    self.titleLabel.text = news.title;
    self.commentNumberLabel.text = [NSString stringWithFormat:@"%ld",news.commentNumber];
    self.clickNumberLabel.text = [NSString stringWithFormat:@"%ld",news.clickNumber];
    self.timeLabel.text = news.time;
}
@end
