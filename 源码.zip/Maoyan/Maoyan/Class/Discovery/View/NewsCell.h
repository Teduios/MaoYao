//
//  NewsCell.h
//  demo1_新闻客户端
//
//  Created by tarena012 on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "news.h"
@interface NewsCell : UITableViewCell

@property (nonatomic,strong)news *news;


@end
