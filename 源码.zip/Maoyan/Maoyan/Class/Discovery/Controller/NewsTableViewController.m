//
//  NewsTableViewController.m
//  demo1_新闻客户端
//
//  Created by tarena012 on 15/12/11.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "NewsTableViewController.h"
#import "news.h"
#import "NewsCell.h"
#import "SHAutoScrollView.h"
@interface NewsTableViewController ()<SHScrollViewViewDelegate>
@property(nonatomic,strong)NSArray *allNews;
@end


@implementation NewsTableViewController
-(NSArray *)allNews
{
    if (!_allNews) {
        _allNews = [news demoData];
        
    }
    return _allNews;
}
- (void)viewDidLoad {
    [super viewDidLoad];

    
    [self setHeaderViewAD];

}
#pragma mark - 私有方法
/**设置表头视图广告*/
- (void)setHeaderViewAD {
    /** 创建滚动视图*/
    SHAutoScrollView *scrollView = [[SHAutoScrollView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 150)];
    scrollView.delegate = self;
    /** 添加图片*/
    NSArray *imageNameArray = @[@"ad9.jpg",@"ad10.jpg",@"ad12.jpg"];
    NSMutableArray *imageViewArray = [NSMutableArray array];
    for (NSString *imageName in imageNameArray) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:imageName];
        [imageViewArray addObject:imageView];
    }
    [scrollView setImageViewAry:imageViewArray];
    /** 滚动循环时间间隔（必须先设置）*/
    scrollView.timeInterval = 3;
    /** 是否滚动*/
    [scrollView shouldAutoShow:YES];
    [scrollView shouldAddPageControll:YES];
    self.tableView.tableHeaderView = scrollView;
    
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.allNews.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsCell" forIndexPath:indexPath];
    
    
    news *news = self.allNews[indexPath.row];
    

    cell.news = news;
  
    
    return cell;
}
//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 70;
//}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
