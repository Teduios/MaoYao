//
//  FRBuyTicketViewController.h
//  选座Demo
//
//  Created by tarena010 on 16/2/25.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieTime.h"

@interface FRBuyTicketViewController : UIViewController
/**用于接收电是否能购买*/
@property(nonatomic,strong) MovieTime * movieTime;
@end
