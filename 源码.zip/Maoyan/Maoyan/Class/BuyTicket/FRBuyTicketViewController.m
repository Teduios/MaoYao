//
//  FRBuyTicketViewController.m
//  选座Demo
//
//  Created by tarena010 on 16/2/25.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "FRBuyTicketViewController.h"
#import "AFNetworking.h"

@interface FRBuyTicketViewController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation FRBuyTicketViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.webView.delegate = self;
    BOOL sell = [self.movieTime.isSell boolValue];
    NSLog(@"%d",sell);
    if (![self.movieTime.isSell boolValue]) {
        //创建警告框，返回
        [self creatAlertController];
    }else {
        [self loadWebView];
    }
    
}

- (void)loadWebView {
    NSString *urlStr = [self.movieTime.seatUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    MYLog(@"%@",urlStr);
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    [self.webView loadRequest:request];
    self.webView.delegate = self;
}

- (void)creatAlertController {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"对不起" message:@"无法购买该场次" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *actionYes = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction *  _Nonnull action) {
        [self.navigationController popViewControllerAnimated:YES];
    }];

    [alert addAction:actionYes];
    
    [self presentViewController:alert animated:YES completion:nil];
}
#pragma mark - WebViewDelegate

- (void) webViewDidStartLoad:(UIWebView *)webView {
    [MBProgressHUD showMessage:@"loading..." toView:self.webView];
}
- (void) webViewDidFinishLoad:(UIWebView *)webView {
    [MBProgressHUD hideAllHUDsForView:self.webView animated:YES];
}

- (void) webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [MBProgressHUD showError:@"加载失败"];
    MYLog(@"%@",error.userInfo);
}

@end
