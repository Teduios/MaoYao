//
//  FRMovieDetail.h
//  Product_MaoYao
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 电影详情类
 */

@interface FRMovieDetail : NSObject
@property (nonatomic ,strong) NSString *detailDescriptionOfMovie; //电影详情 --> dra
@property (nonatomic ,strong) NSArray *photosArray;//照片url数组 --> photos

@property (nonatomic ,strong) NSNumber *countOfMark;//评论总数 --> snum
@property (nonatomic ,strong) NSString *star;//所有演员
@property (nonatomic ,strong) NSString *directorOfMovie;//电影总导演 --> dir
@property (nonatomic ,strong) NSString *urlOfMovieVideo;//电影视频地址 --> vd
@property (nonatomic ,strong) NSString *sourceOfMovie;//电影源产地 --> src
+ (FRMovieDetail *)parseJSON:(NSDictionary *)movieDetailDic;
@end
