//
//  FRMovie.h
//  项目_哈哈
//
//  Created by tarena032 on 16/1/13.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FRMovieDetail.h"

/**
 电影类
 根据api获得的json数据所创建的
 所对应的json为：json[@"data"][@"movies"]
 详细key值见 "-->" 之后
 */
@interface FRMovie : NSObject

@property (nonatomic ,strong) NSNumber *countOfCinema;//上映电影院的个数 --> cnms
@property (nonatomic ,strong) NSNumber *countOfScene;//上映的总场次 --> sn
@property (nonatomic ,strong) NSString *showInfoOfMovie;//电影上映信息 --> showInfo
@property (nonatomic ,strong) NSNumber *durationOfMovie;//上映时长 --> rt
@property (nonatomic ,strong) NSNumber *countOfWish;//想看人的总数 --> wish
@property (nonatomic ,strong) NSNumber *idOfMovie;//电影的id --> id
@property (nonatomic ,strong) NSNumber *countOfPreSale;//电影票预售总数 --> preSale
@property (nonatomic ,strong) NSNumber *markOfMovie;//电影评分 --> sc 

@property (nonatomic ,strong) NSString *nameOfMovie;//电影名字 --> nm

@property (nonatomic ,strong) NSString *briefOfMovie;//电影简介 --> scm
@property (nonatomic ,strong) NSString *versionOfMovie;//电影版本（2D/3D...） --> ver
@property (nonatomic ,strong) NSString *dateOfShow;//上映日期 --> rt
@property (nonatomic ,strong) NSString *imgUrlOfMovie;//电影图片的URL --> img
@property (nonatomic ,strong) NSString *directorName;//导演姓名 -> dir
@property (nonatomic ,strong) NSString *starName;//所有演员姓名 -> star
@property (nonatomic ,strong) NSString *typeOfMovie;//电影的类型 -> cat

@property (nonatomic ,getter=isThreeD) BOOL threeD;//是否是3D --> 3d
@property (nonatomic ,getter=isIMax) BOOL iMax;//是否时iMax --> imax
@property (nonatomic ) NSInteger preSale;//电影是否已经上映（0：已经上映） --> preSale

@property (nonatomic ,strong) FRMovieDetail *movieDetail;
/**
 解析json中电影字典的内容，封装并返回FRMovie类
 */
+ (id) parseJSON:(NSDictionary *)movieDic;

/**
 判断电影的版本，并获得相应的图片名
 */
+ (NSString *)getVersionImageNameWithModel:(FRMovie *)movie;
@end
