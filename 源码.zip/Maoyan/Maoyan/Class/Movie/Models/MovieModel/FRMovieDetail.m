//
//  FRMovieDetail.m
//  Product_MaoYao
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRMovieDetail.h"

@implementation FRMovieDetail

+ (FRMovieDetail *)parseJSON:(NSDictionary *)movieDetailDic {
    FRMovieDetail *movieDetail = [FRMovieDetail new];
    movieDetail.directorOfMovie = movieDetailDic[@"dir"];
    movieDetail.detailDescriptionOfMovie = movieDetailDic[@"dra"];
    movieDetail.countOfMark = movieDetailDic[@"snum"];
    movieDetail.star = movieDetailDic[@"star"];
    movieDetail.urlOfMovieVideo = movieDetailDic[@"vd"];
    movieDetail.sourceOfMovie = movieDetailDic[@"src"];
    return movieDetail;
}
@end
