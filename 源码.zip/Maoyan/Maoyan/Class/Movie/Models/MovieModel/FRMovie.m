//
//  FRMovie.m
//  项目_哈哈
//
//  Created by tarena032 on 16/1/13.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRMovie.h"

@implementation FRMovie
+(id)parseJSON:(NSDictionary *)movieDic{
    return [[self alloc]initWithMovieDic:movieDic];
}
-(id)initWithMovieDic:(NSDictionary *)movieDic{
    if (self = [super init]) {
        self.countOfCinema = movieDic[@"cnms"];
        self.countOfScene = movieDic[@"sn"];
        self.showInfoOfMovie = movieDic[@"showInfo"];
        self.durationOfMovie = movieDic[@"dur"];
        self.countOfWish = movieDic[@"wish"];
        self.idOfMovie = movieDic[@"id"];
        self.countOfPreSale = movieDic[@"preSale"];
        
        self.nameOfMovie = movieDic[@"nm"];
        self.briefOfMovie = movieDic[@"scm"];
        self.versionOfMovie = movieDic[@"ver"];
        self.dateOfShow = movieDic[@"rt"];
        self.imgUrlOfMovie = movieDic[@"img"];
        self.directorName = movieDic[@"dir"];
        self.starName = movieDic[@"star"];
        self.typeOfMovie = movieDic[@"cat"];
        self.markOfMovie = movieDic[@"sc"];
#warning TODO:判断bool改成BOOL
        
        self.threeD = [movieDic[@"3d"] boolValue];
        self.iMax = [movieDic[@"imax"] boolValue];
        self.preSale = [movieDic[@"preSale"] integerValue];
        
    }
    return self;
}

+ (NSString *)getVersionImageNameWithModel:(FRMovie *)movie {
    if (movie.isIMax) {
        if (movie.isThreeD) {
            //iMax 3D
            return @"tag_3d_imax";
        }else {
            //iMax 2D
            return @"tag_2d_imax";
        }
    }else {
        if (movie.isThreeD) {
            //3D
            return @"tag_3d";
        }else {
            //2D
            return @"IconEmpty";
        }
    }
}
@end
