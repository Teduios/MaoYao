//
//  FRCommenter.h
//  Maoyan
//
//  Created by tarena032 on 16/2/17.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FRCommenter : NSObject
/** 昵称-->nickName*/
@property (nonatomic ,strong) NSString *nickName;
@property (nonatomic ,strong) NSString *nick;
/** 头像url --> avatarurl*/
@property (nonatomic ,strong) NSString *avatarurl;
/** 赞 --> approve*/
@property (nonatomic ,strong) NSNumber *approve;
/** 反对 --> oppose*/
@property (nonatomic ,strong) NSNumber *oppose;
/** 回复 --> reply*/
@property (nonatomic ,strong) NSNumber *reply;
/** 用户id --> userId*/
@property (nonatomic ,strong) NSString *userId;
@property (nonatomic ,strong) NSNumber *Id;
/** 评分 --> score*/
@property (nonatomic ,strong) NSNumber *score;
/** 时间 --> time*/
@property (nonatomic ,strong) NSString *time;
/** 评论内容 --> content*/
@property (nonatomic ,strong) NSString *content;
/** VIP信息*/
@property (nonatomic ,strong) NSString *vipInfo;
@end
