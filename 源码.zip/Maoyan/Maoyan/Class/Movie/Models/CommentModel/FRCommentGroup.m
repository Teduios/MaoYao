//
//  FRCommentGroup.m
//  Maoyan
//
//  Created by tarena032 on 16/2/17.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCommentGroup.h"

@implementation FRCommentGroup

- (instancetype)init {
    if (self = [super init]) {
        _hcmts = [NSMutableArray array];
        _cmts = [NSMutableArray array];
    }
    return self;
}


@end
