//
//  FRCommentGroup.h
//  Maoyan
//
//  Created by tarena032 on 16/2/17.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FRCommentGroup : NSObject
/** 热门评论数组*/
@property (nonatomic ,strong) NSMutableArray *hcmts;
/** 一般评论数组*/
@property (nonatomic ,strong) NSMutableArray *cmts;
/** 评论总数*/

@end
