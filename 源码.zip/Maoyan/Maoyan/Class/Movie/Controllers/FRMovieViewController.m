//
//  FRMovieViewController.m
//  猫妖
//
//  Created by tarena010 on 16/1/13.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "FRMovieViewController.h"
#import "FRHotScreenTableViewController.h"
#import "FROverseaTableViewController.h"
#import "FRLocationManager.h"
#import "TSMessage.h"
#import "FRCityGroupTableViewController.h"
#import "SHNavViewController.h"
#import "FRSearchTableViewController.h"
#import "FRWillOnTableViewController.h"

@interface FRMovieViewController (){
    /**城市名字*/
    NSString *_cityName;
}

@end

@implementation FRMovieViewController
-(instancetype)init{
    if (self = [super init]) {
        FRHotScreenTableViewController *hotScreenVC = [FRHotScreenTableViewController new];
        
        
       // testTableViewController *vc2 =[[testTableViewController alloc]init];
        FRWillOnTableViewController *willOnVC = [[FRWillOnTableViewController alloc]init];
        //vc2.view.backgroundColor = [UIColor redColor];
        
        FROverseaTableViewController *overseaVC =[[FROverseaTableViewController alloc]init];
        
        self.segmentBgColor = [UIColor colorWithRed:211.0f/255 green:42.0f/255 blue:45.0f/255 alpha:1.0f];
        //self.segmentBgColor = [UIColor darkGrayColor];
        self.indicatorViewColor = [UIColor whiteColor];
        self.titleColor = [UIColor whiteColor];
        [self setViewControllers:@[hotScreenVC,willOnVC,overseaVC]];
        [self setTitles:@[@"热映", @"待映", @"其它"]];
        
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBackgroundColor:[UIColor clearColor]];
    //监听
    [self listenNotification];
    /**开始定位*/
    [self getLocation];
    /**设置导航栏左右两边按钮*/
    [self setNavBarItem];
}

- (void)setNavBarItem {
    UIButton *btn = [UIButton new];
    btn.frame = CGRectMake(-40, 0, 50, 25);
    if (!_cityName) {
        _cityName = @"杭州";
    }
    [btn setTitle:_cityName forState:(UIControlStateNormal)];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    [btn setTitleColor:self.navigationController.navigationBar.tintColor forState:(UIControlStateNormal)];

    [btn setImage:[UIImage imageNamed:@"ic_moreInfo_arrowDown"] forState:(UIControlStateNormal)];
    UIBarButtonItem *leftBarBtn = [[UIBarButtonItem alloc]initWithCustomView:btn];
    [btn addTarget:self action:@selector(chooseCity) forControlEvents:(UIControlEventTouchUpInside)];
    self.navigationItem.leftBarButtonItem = leftBarBtn;
    
    UIBarButtonItem *rightBatBtn = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"icon_search_glass"] style:(UIBarButtonItemStylePlain) target:self action:@selector(search)];
    self.navigationItem.rightBarButtonItem = rightBatBtn;
}

#pragma mark - 单纯定位
-(void)getLocation{
    [FRLocationManager getUserLocation:^(double lat, double lon) {
        CLLocation *location = [[CLLocation alloc]initWithLatitude:lat longitude:lon];
        [self getCityName:location];
    }];
}

//反地理编码
-(void)getCityName:(CLLocation*)location{
    CLGeocoder *geocoder = [CLGeocoder new];
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (!error) {
            CLPlacemark *placemark = [placemarks lastObject];
            NSString *str = placemark.addressDictionary[@"City"];
            _cityName = [str substringToIndex:[str length] - 1];
        }else{
            [TSMessage showNotificationWithTitle:@"提示" subtitle:@"定位失败" type:(TSMessageNotificationTypeWarning)];
        }
    }];
}

#pragma mark - 通知，改变城市
-(void)listenNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(listenChangeCity:) name:@"DidCityChange" object:nil];
}

-(void)listenChangeCity:(NSNotification*)notification{
    //获取传过来的参数
    NSString *cityName = notification.userInfo[@"CiytName"];
    _cityName = cityName;
    [self setNavBarItem];
    //重新发请求 q = 上海 -> q = shanghai
    //    [self sendRequestToServer:cityName];
}

#pragma mark - 点击触发定位
-(void)locationCiry{
    FRCityGroupTableViewController *cityVC = [[FRCityGroupTableViewController alloc]init];
    UINavigationController *cityNavi = [[UINavigationController alloc]initWithRootViewController:cityVC];
    [self presentViewController:cityNavi animated:YES completion:nil];
}

- (void)chooseCity {
    FRCityGroupTableViewController *cityVC = [FRCityGroupTableViewController new];
    SHNavViewController *navi = [[SHNavViewController alloc]initWithRootViewController:cityVC];
    [self presentViewController:navi animated:YES completion:nil];
}

- (void)search {
    FRSearchTableViewController *searchVC = [FRSearchTableViewController new];
    SHNavViewController *navi = [[SHNavViewController alloc]initWithRootViewController:searchVC];
    [self presentViewController:navi animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
