//
//  FRMovieDetailTableViewController.h
//  Maoyan
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FRMovie.h"

@interface FRMovieDetailTableViewController : UITableViewController
@property (nonatomic ,strong) FRMovie *movie;
@end
