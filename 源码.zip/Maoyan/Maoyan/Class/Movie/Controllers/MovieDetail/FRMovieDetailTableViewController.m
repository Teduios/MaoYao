//
//  FRMovieDetailTableViewController.m
//  Maoyan
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRMovieDetailTableViewController.h"
#import "FRMovieTool.h"
#import "FRMovieDetailCell.h"
#import "FRBriefCell.h"
#import "FRCommentCell.h"
#import "FRCommentGroup.h"
#import "FRCommentTool.h"
#import "SHNavViewController.h"
#import "FRCinemaTableViewController.h"


@interface FRMovieDetailTableViewController ()
@property (strong, nonatomic) IBOutlet FRBriefCell *briefCell;
@property (nonatomic ,strong) FRCommentGroup *commentGroup;
@property (strong, nonatomic) IBOutlet UITableViewCell *buyTicketCell;

@end

@implementation FRMovieDetailTableViewController

- (void)setMovie:(FRMovie *)movie {
    _movie = movie;
    [FRMovieTool getMovieDetailWithMovie:movie success:^(FRMovie *movie) {
        //
       // MYLog(@"111");
        MYLog(@"获取电影详情成功%@",movie.movieDetail);
        _movie = movie;
        [self.tableView reloadData];
        /** 获取电影评论*/
        [self getCommentData];

    } failure:^(NSError *error) {
        //
        MYLog(@"获取电影详情失败%@",error.userInfo);
    }];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self configLeftNavItem];
    self.navigationItem.title = self.movie.nameOfMovie;
}

#pragma mark - 私有方法
/** 设置导航栏左边的item*/
- (void)configLeftNavItem {

    self.navigationItem.hidesBackButton = YES;
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"navigationBar_back"] style:(UIBarButtonItemStylePlain) target:self action:@selector(clickBackItem)];
    self.navigationItem.leftBarButtonItem = backItem;
}
/** 点击返回item*/
- (void)clickBackItem {
    [self.navigationController popViewControllerAnimated:YES];
    
}

/** 获得评论信息*/
- (void)getCommentData {
    NSString *urlStr = [NSString stringWithFormat:@"http://m.maoyan.com/movie/%@.json",self.movie.idOfMovie];
    [FRCommentTool getAllCommentData:urlStr parameters:nil success:^(FRCommentGroup *comments) {
        self.commentGroup = comments;
        [self.tableView reloadData];
    } failure:^(NSError *error) {
        MYLog(@"%@",error);
    }];
}

- (IBAction)clickBuyTicketBtn:(id)sender {
     SHNavViewController *cinemaNavi = [[UIStoryboard storyboardWithName:@"Cinema" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
    FRCinemaTableViewController *cinemaController = cinemaNavi.viewControllers[0];
    [cinemaController showGoBackItem:YES];
    [self presentViewController:cinemaNavi animated:YES completion:nil];
   
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    switch (section) {
        case 0:
            return 3;
            break;
        case 1:
            return self.commentGroup.hcmts.count + 1;
            break;
        case 2:
            return self.commentGroup.cmts.count + 1;
            break;
        default:
            return 0;
            break;
    }

}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"commentCell";
    switch (indexPath.section) {
        case 0:
            if (indexPath.row == 0) {
                FRMovieDetailCell *cell = [FRMovieDetailCell getMovieDetailCellWithMovie:self.movie];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                // Configure the cell...
                return cell;
                
            }else if (indexPath.row == 2) {
                if (self.movie.movieDetail.detailDescriptionOfMovie.length == 0) {
                    self.briefCell.briefLabel.text = @"无";
                }else{
                    self.briefCell.briefLabel.text = [[self.movie.movieDetail.detailDescriptionOfMovie stringByReplacingOccurrencesOfString:@"<p>" withString:@""] stringByReplacingOccurrencesOfString:@"<\/p>" withString:@""];
                    self.briefCell.selectionStyle = UITableViewCellSelectionStyleNone;
                }
                return self.briefCell;
            }else {
                return self.buyTicketCell;
            }

            break;
        case 1:
        {
            if (indexPath.row == 0) {
                UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"section"];
                cell.textLabel.text = @"热门评论";
                return cell;
            }else{
                FRCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
                if (!cell) {
                    cell = [[[NSBundle mainBundle] loadNibNamed:@"FRCommentCell" owner:self options:nil] lastObject];
                }
                FRCommenter *commenter = self.commentGroup.hcmts[indexPath.row - 1];
                cell.commenter = commenter;
                return cell;
            }
            
        }
            break;
        case 2:
        {
            if (indexPath.row == 0) {
               UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"section"];
                cell.textLabel.text = @"一般评论";
                return cell;
            }else{
                FRCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
                if (!cell) {
                    cell = [[[NSBundle mainBundle] loadNibNamed:@"FRCommentCell" owner:self options:nil] lastObject];
                }
                FRCommenter *commenter = self.commentGroup.cmts[indexPath.row - 1];
                cell.commenter = commenter;
                return cell;
            }

        }
            break;
        default:
 
            break;
    }
           return nil;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
            if (indexPath.row == 1) {
                return 44;
            }
            return 160;
            break;
        case 1:
            if (indexPath.row == 0) {
                return 44;
            }else{
                return 200;
            }
           
            break;
        case 2:
            if (indexPath.row == 0) {
                return 44;
            }else{
                return 100;
            }

            break;
        default:
            return 0;
            break;
    }

}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5;
}
@end

