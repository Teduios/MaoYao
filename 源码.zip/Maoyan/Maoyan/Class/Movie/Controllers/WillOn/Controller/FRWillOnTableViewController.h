//
//  FRWillOnTableViewController.h
//  Maoyan
//
//  Created by tarena010 on 16/2/23.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRWillOnTableViewController : UITableViewController

@end
