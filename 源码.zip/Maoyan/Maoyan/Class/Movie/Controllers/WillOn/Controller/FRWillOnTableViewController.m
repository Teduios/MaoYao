//
//  FRWillOnTableViewController.m
//  Maoyan
//
//  Created by tarena010 on 16/2/23.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRWillOnTableViewController.h"
#import "MovieView.h"
#import "FRMovieTool.h"
#import "UIView+Extension.h"
#import "UIImageView+WebCache.h"
#import "FRScrollView.h"
#import "FRMovieCell.h"
#import "FRMovieDetailTableViewController.h"

@interface FRWillOnTableViewController ()
/**未上映 受期待的电影数组*/
@property(nonatomic,strong) NSMutableArray *exceptMovieArray;
/**近期期待电影的scrollview*/
@property(nonatomic,strong) UIScrollView * scrollView;
/**选中的电影*/
//@property(nonatomic,strong) FRMovie * chooseMovie;
@end

@implementation FRWillOnTableViewController
static NSString *urlOfHotScreen = @"http://m.maoyan.com/movie/list.json?type=hot&offset=0&limit=1000";//热映页面api

- (NSMutableArray *)exceptMovieArray {
    if (!_exceptMovieArray) {
        _exceptMovieArray = [NSMutableArray array];
    }
    return _exceptMovieArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //下载电影
    [self loadMovieData];
    UIView *header = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.tableView.width, 10)];
    header.backgroundColor = [UIColor groupTableViewBackgroundColor];
    self.tableView.tableHeaderView = header;

}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}
- (void)loadMovieData {
    [FRMovieTool getAllMovieDataWithUrlString:urlOfHotScreen parameters:nil success:^(id allMovieArray) {
        for (FRMovie *movie in allMovieArray) {
            if (movie.preSale) {
                [self.exceptMovieArray addObject:movie];
                //设置scrollview
                [self setScrollview];
                [self.tableView reloadData];
            }
        }
    } failure:^(NSError *error) {
        MYLog(@"获取即将上映电影首页数据失败%@",error.userInfo);
    }];
}

- (void)setScrollview {
    NSMutableArray *contentViewsArray = [NSMutableArray array];
    for (FRMovie *movie in self.exceptMovieArray) {
        MovieView *movieView = [[[NSBundle mainBundle] loadNibNamed:@"MovieView" owner:self options:nil] firstObject];
        movieView.movie = movie;
//        [movieView.detailBtn addTarget:self action:@selector(gotoDetailWithMovie:) forControlEvents:(UIControlEventTouchUpInside)];
        [contentViewsArray addObject:movieView];
    }
    self.scrollView = [FRScrollView creatScrollViewWithFrame:CGRectMake(0, 0, self.tableView.width, 160) WithContents:contentViewsArray AndViewWidth:100];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }else {
        return self.exceptMovieArray.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc]init];
        [cell.contentView addSubview: self.scrollView];
        return cell;
    }else {
        FRMovieCell *movieCell = [tableView dequeueReusableCellWithIdentifier:@"movieCell" ];
        
        FRMovie *movie = self.exceptMovieArray[indexPath.row];
        
        movieCell = [FRMovieCell getMovieCellWithMovieModel:movie];

        return movieCell;
    }
    
    
}

//cell高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 160;
    }else {
        return 90;
    }
}

//分区头
- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *title = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, 30, 10)];
    title.backgroundColor = [UIColor groupTableViewBackgroundColor];
    title.font = [UIFont systemFontOfSize:13];
    if (section == 0) {
        title.text = @"近期推荐";
    }else {
        title.text = @"即将上映";
    }
    
    return title;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FRMovie *movie = self.exceptMovieArray[indexPath.row];
    [self gotoDetailWithMovie:movie];
}

//跳转
- (void)gotoDetailWithMovie:(FRMovie*)movie {
    FRMovieDetailTableViewController *movieDetailViewController = [FRMovieDetailTableViewController new];
    movieDetailViewController.movie = movie;
    [self.navigationController pushViewController:movieDetailViewController animated:YES];
    self.tabBarController.tabBar.hidden = YES;

}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
