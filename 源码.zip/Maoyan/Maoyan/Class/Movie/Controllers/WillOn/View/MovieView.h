//
//  MovieView.h
//  Maoyan
//
//  Created by tarena010 on 16/2/25.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FRMovie.h"

@interface MovieView : UIView
@property(nonatomic,strong) FRMovie * movie;
@property (weak, nonatomic) IBOutlet UIButton *detailBtn;

@end
