//
//  MovieView.m
//  Maoyan
//
//  Created by tarena010 on 16/2/25.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "MovieView.h"
#import "UIImageView+WebCache.h"
#import "FRMovieDetailTableViewController.h"

@interface MovieView ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *dateOfShow;
@property (weak, nonatomic) IBOutlet UILabel *nameOfMovie;
@property (weak, nonatomic) IBOutlet UILabel *countOfWish;

@end

@implementation MovieView

- (void)setMovie:(FRMovie *)movie {
    _movie = movie;
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:movie.imgUrlOfMovie]];
    if (movie.showInfoOfMovie.length > 10) {
        self.dateOfShow.text = [movie.showInfoOfMovie substringFromIndex:10];
    }else {
        self.dateOfShow.text = movie.dateOfShow;

    }
    
    self.nameOfMovie.text = movie.nameOfMovie;
    self.countOfWish.text = [NSString stringWithFormat:@"%@想看",movie.countOfWish];
}
- (IBAction)clcikWish:(UIButton*)sender {
    sender.selected = !sender.selected;
}



@end
