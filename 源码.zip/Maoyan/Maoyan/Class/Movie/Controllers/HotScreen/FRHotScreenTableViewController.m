//
//  FRHotScreenTableViewController.m
//  Maoyan
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRHotScreenTableViewController.h"
#import "FRMovieDetailTableViewController.h"
#import "FRMovieTool.h"
#import "UIView+Extension.h"
#import "FRScrollView.h"
#import "FRMovieCell.h"
#import "FRMovie.h"
#import "UIImageView+WebCache.h"
#import "SHAutoScrollView.h"

/**
 热映电影控制器
 显示正在热映的所有电影信息
 */
@interface FRHotScreenTableViewController ()<SHScrollViewViewDelegate,UIScrollViewDelegate>
//存放所有电影数据，成员是FRMovie类型
@property (nonatomic ,strong) NSArray *allMovieArray;
@end

@implementation FRHotScreenTableViewController

static NSString *urlOfHotScreen = @"http://m.maoyan.com/movie/list.json?type=hot&offset=0&limit=1000";//热映页面api

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBarController.tabBar.hidden = NO;
    //设置表头视图广告
    [self setHeaderViewAD];
    
    //加载电影json数据
    [self loadMovieData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
}
#pragma mark - 私有方法
/**设置表头视图广告*/
- (void)setHeaderViewAD {
    /** 创建滚动视图*/
    SHAutoScrollView *scrollView = [[SHAutoScrollView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 80)];
    scrollView.delegate = self;
    /** 添加图片*/
    NSArray *imageNameArray = @[@"ad1.jpg",@"ad2.jpg",@"ad3.jpg",@"ad4.jpg",@"ad5.jpg",@"ad6.jpg",@"ad7.jpg",@"ad8.jpg"];
    NSMutableArray *imageViewArray = [NSMutableArray array];
    for (NSString *imageName in imageNameArray) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:imageName];
        //imageView.contentMode = UIViewContentModeScaleAspectFit;
        [imageViewArray addObject:imageView];
    }
    [scrollView setImageViewAry:imageViewArray];
    /** 滚动循环时间间隔（必须先设置）*/
    scrollView.timeInterval = 3;
    /** 是否滚动*/
    [scrollView shouldAutoShow:YES];
    self.tableView.tableHeaderView = scrollView;
}

/**加载电影json数据*/
- (void)loadMovieData {
    [MBProgressHUD showMessage:@"加载数据中\n请稍后" toView:self.tableView];
    [FRMovieTool getAllMovieDataWithUrlString:urlOfHotScreen parameters:nil success:^(id allMovieArray) {
        //
        self.allMovieArray = allMovieArray;
        [MBProgressHUD hideHUDForView:self.tableView animated:YES];
        [self.tableView reloadData];
    } failure:^(NSError *error) {
       MYLog(@"获取热映电影首页数据失败%@",error.userInfo);
       [MBProgressHUD showError:@"加载失败\n请检查网络"];
    }];
}

/** 下拉刷新*/
- (void) setupRefresh {
    //添加刷新空间
    UIRefreshControl *refresh = [[UIRefreshControl alloc]init];
    refresh.tintColor = [UIColor redColor];
    [refresh addTarget:self action:@selector(refreshStateChange:) forControlEvents:(UIControlEventValueChanged)];
    [self.tableView addSubview:refresh];
    //开始刷新
    [refresh beginRefreshing];
    //请求数据
    [self refreshStateChange:refresh];
}
- (void) refreshStateChange:(UIRefreshControl *)refresh {
    [FRMovieTool getAllMovieDataWithUrlString:urlOfHotScreen parameters:nil success:^(NSArray *allMovieArray) {
        [self.tableView reloadData];
        
        [refresh endRefreshing];
    } failure:^(NSError *error) {
        [refresh endRefreshing];
    }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allMovieArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    //电影单元格
    FRMovieCell *movieCell = [tableView dequeueReusableCellWithIdentifier:@"movieCell" ];
    // Configure the cell...
    
    FRMovie *movie = self.allMovieArray[indexPath.row];
    
    movieCell = [FRMovieCell getMovieCellWithMovieModel:movie];

    
    
    return movieCell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FRMovie *movie = self.allMovieArray[indexPath.row];
    FRMovieDetailTableViewController *movieDetailViewController = [FRMovieDetailTableViewController new];
    movieDetailViewController.movie = movie;
    [self.navigationController pushViewController:movieDetailViewController animated:YES];
    self.tabBarController.tabBar.hidden = YES;
}

#pragma mark - scrollViewDelegate 
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
}

@end
