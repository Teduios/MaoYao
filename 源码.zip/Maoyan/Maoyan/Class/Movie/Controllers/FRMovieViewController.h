//
//  FRMovieViewController.h
//  猫妖
//
//  Created by tarena010 on 16/1/13.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "SHSegmentViewController.h"
/**
 电影控制器
主要负责对应导航栏上的分页切换和视图切换的控制
 
 */

@interface FRMovieViewController : SHSegmentViewController

@end
