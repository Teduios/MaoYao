//
//  SHNavViewController.m
//  SearchDeal
//
//  Created by tarena032 on 16/1/21.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "SHNavViewController.h"

@interface SHNavViewController ()

@end
@implementation SHNavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 获取navigationBar
    self.navigationBar.backgroundColor = [UIColor lightGrayColor];
    self.navigationBar.tintColor = [UIColor blackColor];
}





@end
