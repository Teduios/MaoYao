//
//  FROverseaTableViewController.m
//  Maoyan
//
//  Created by tarena010 on 16/2/19.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FROverseaTableViewController.h"
#import "FRMovieCell.h"
#import "FRMovie.h"
#import "FRMovieTool.h"
#import "FRMovieDetailTableViewController.h"

@interface FROverseaTableViewController (){
    
}
/**所有电影详情数组*/
@property(nonatomic,strong) NSMutableArray * detailMovieArray;
/**所有电影数组*/
@property(nonatomic,strong) NSArray * allMovieArray;
/**显示到界面的数组*/
@property(nonatomic,strong) NSMutableArray * countryMovieArray;
@property(nonatomic,strong) UISegmentedControl *segmentedControl;
@end

@implementation FROverseaTableViewController

- (NSMutableArray *)detailMovieArray {
    if (!_detailMovieArray) {
        _detailMovieArray = [NSMutableArray array];
    }
    return _detailMovieArray;
}

- (NSMutableArray *)countryMovieArray {
    if (!_countryMovieArray) {
        _countryMovieArray = [NSMutableArray array];
    }
    return _countryMovieArray;
}


static NSString *urlOfHotScreen = @"http://m.maoyan.com/movie/list.json?type=hot&offset=0&limit=1000";//热映页面api

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建segment
    [self addSegment];
    //得到全部电影数据
    [self loadMovieData];

}

- (void)addSegment {
    self.segmentedControl = [[UISegmentedControl alloc]initWithItems:nil];
    //设置segmentedControl
    
    self.segmentedControl.tintColor = [UIColor clearColor];//去掉颜色,现在整个segment都看不见
    NSDictionary* selectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:14],
                                             NSForegroundColorAttributeName: [UIColor colorWithRed:211.0f/255 green:42.0f/255 blue:45.0f/255 alpha:1.0f]};
    [self.segmentedControl setTitleTextAttributes:selectedTextAttributes forState:UIControlStateSelected];//设置文字属性
    NSDictionary* unselectedTextAttributes = @{NSFontAttributeName:[UIFont boldSystemFontOfSize:14],
                                               NSForegroundColorAttributeName: [UIColor blackColor]};
    //增加分段
    [self.segmentedControl setTitleTextAttributes:unselectedTextAttributes forState:UIControlStateNormal];
    [self.segmentedControl insertSegmentWithTitle:@"美国" atIndex:0 animated:NO];
    [self.segmentedControl insertSegmentWithTitle:@"香港" atIndex:1 animated: NO ];
    [self.segmentedControl insertSegmentWithTitle:@"日本" atIndex:2 animated: NO ];
    self.tableView.tableHeaderView = self.segmentedControl;
    [self.segmentedControl addTarget: self action: @selector(controlPressed:) forControlEvents: UIControlEventValueChanged];
}

- (void)controlPressed:(UISegmentedControl*)sender {
    [self.countryMovieArray removeAllObjects];
    self.segmentedControl = sender;
    NSString *country;
    switch (self.segmentedControl.selectedSegmentIndex) {
        case 0:
            country = @"美国";
            break;
        case 1:
            country = @"香港";
            break;
        case 2:
            country = @"日本";
            break;
        default:
            break;
    }
    for (FRMovie *movie in self.allMovieArray) {
        if ([movie.movieDetail.sourceOfMovie containsString:country]) {
            [self.countryMovieArray addObject:movie];
        }
    }
    [self.tableView reloadData];
}

/**加载电影json数据*/
- (void)loadMovieData {
    [FRMovieTool getAllMovieDataWithUrlString:urlOfHotScreen parameters:nil success:^(id allMovieArray) {
        self.allMovieArray = allMovieArray;
        for (FRMovie *movie in self.allMovieArray) {
            [FRMovieTool getMovieDetailWithMovie:movie success:^(FRMovie *movie) {
                [self.detailMovieArray addObject:movie];
                //初始化
                self.segmentedControl.selectedSegmentIndex = 0;
                [self controlPressed:self.segmentedControl];
            } failure:^(NSError *error) {
                MYLog(@"获取海外电影数据失败%@",error.userInfo);
            }];
        }
    } failure:^(NSError *error) {
        MYLog(@"获取海外电影首页数据失败%@",error.userInfo);
    }];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.countryMovieArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    //电影单元格
    FRMovieCell *movieCell = [tableView dequeueReusableCellWithIdentifier:@"movieCell" ];
    
    FRMovie *movie = self.countryMovieArray[indexPath.row];
    
    movieCell = [FRMovieCell getMovieCellWithMovieModel:movie];
    
    return movieCell;
}

//设置分区头
- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *country = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 30, 10)];
    country.backgroundColor = [UIColor groupTableViewBackgroundColor];
    country.font = [UIFont systemFontOfSize:13];
    switch (self.segmentedControl.selectedSegmentIndex) {
        case 0:
            country.text = @"美国热映";
            break;
        case 1:
            country.text = @"香港热映";
            break;
        case 2:
            country.text = @"日本热映";
            break;
        default:
            break;
    }
    return country;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

//点击cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FRMovie *movie = self.countryMovieArray[indexPath.row];
    FRMovieDetailTableViewController *movieDetailViewController = [FRMovieDetailTableViewController new];
    movieDetailViewController.movie = movie;
    [self.navigationController pushViewController:movieDetailViewController animated:YES];
    self.tabBarController.tabBar.hidden = YES;
}




/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here, for example:
    // Create the next view controller.
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:<#@"Nib name"#> bundle:nil];
    
    // Pass the selected object to the new view controller.
    
    // Push the view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
