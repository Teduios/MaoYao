//
//  FRMovieCell.m
//  电影购票
//
//  Created by tarena010 on 16/1/7.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "FRMovieCell.h"
#import "UIImageView+WebCache.h"

/**
 电影单元格
 通过getMovieCellWithMovieModel方法返回获得一个cell对象
 */
@interface FRMovieCell ()

@property (weak, nonatomic) IBOutlet UIImageView *imageViewOfMovie;//图片

@property (weak, nonatomic) IBOutlet UILabel *nameOfMovieLabel;//名字
@property (weak, nonatomic) IBOutlet UILabel *briefOfMovieLabel;//简介
@property (weak, nonatomic) IBOutlet UILabel *scenesInfoLabel;//上映场次信息
@property (weak, nonatomic) IBOutlet UILabel *markOfMovieLabel;//评分
@property (weak, nonatomic) IBOutlet UIImageView *versionOfMovieImageView;//版本图片
@property (weak, nonatomic) IBOutlet UIButton *button;//购票

@end

@implementation FRMovieCell

+ (FRMovieCell *)getMovieCellWithMovieModel:(FRMovie *)movie {
    return [FRMovieCell creatWith:movie];
}

+ (instancetype)creatWith:(FRMovie *)movie{
   FRMovieCell *cell = [[[NSBundle mainBundle]loadNibNamed:@"FRMovieCell" owner:nil options:nil]lastObject];
    /** 设置cell的背景图*/
    [cell setBackground];

    
    [cell.imageViewOfMovie sd_setImageWithURL:[NSURL URLWithString:movie.imgUrlOfMovie] placeholderImage:[UIImage imageNamed:@"bg_movie_picker_placeholder"]];
    cell.versionOfMovieImageView.image = [UIImage imageNamed:[FRMovie getVersionImageNameWithModel:movie]];//图片
    
    cell.nameOfMovieLabel.text = movie.nameOfMovie;//名字
    cell.briefOfMovieLabel.text = movie.briefOfMovie;//简介
    cell.scenesInfoLabel.text = ![movie.showInfoOfMovie isEqual:@""]?movie.showInfoOfMovie : movie.dateOfShow;//上映场次
    [cell.button setTitle:[NSString stringWithFormat:@"%@",!movie.preSale?@"购票":@"预售"] forState:(UIControlStateNormal)];//按钮
    [cell.button setBackgroundImage:[UIImage imageNamed:movie.preSale?@"reserveBlue_btn":@"reserve_btn"] forState:(UIControlStateNormal)];
    [cell.button setBackgroundImage:[UIImage imageNamed:movie.preSale?@"reserveBlue_btn_pressed":@"reserve_btn_pressed"] forState:(UIControlStateHighlighted)];
    if (movie.preSale) {
        [cell.button setTitleColor:[UIColor blueColor] forState:(UIControlStateNormal)];
    }else{
        [cell.button setTitleColor:[UIColor redColor] forState:(UIControlStateNormal)];
    }
    cell.markOfMovieLabel.text = !movie.preSale?[NSString stringWithFormat:@"%.1f分",[movie.markOfMovie floatValue]]:[NSString stringWithFormat:@"%@人想看",movie.countOfWish];
    return cell;
}




@end
