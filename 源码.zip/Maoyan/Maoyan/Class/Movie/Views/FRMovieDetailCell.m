//
//  FRMovieDetailCell.m
//  Maoyan
//
//  Created by tarena032 on 16/1/29.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRMovieDetailCell.h"
#import "UIButton+WebCache.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"

@interface FRMovieDetailCell ()
@property (weak, nonatomic) IBOutlet UIImageView *bgMovieImageView;
@property (weak, nonatomic) IBOutlet UIButton *movieImageButton;
@property (weak, nonatomic) IBOutlet UILabel *movieNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *movieVersionImageView;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *allStarImageView;

@property (weak, nonatomic) IBOutlet UILabel *markOfImageLabel;
@property (weak, nonatomic) IBOutlet UILabel *movieTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *sourceAndDurLabel;
@property (weak, nonatomic) IBOutlet UILabel *showDateLabel;
@property (nonatomic ,strong) FRMovie *movie;
@end

@implementation FRMovieDetailCell

+ (FRMovieDetailCell *)getMovieDetailCellWithMovie:(FRMovie *)movie {
    
    FRMovieDetailCell *cell = [[[NSBundle mainBundle]loadNibNamed:@"FRMovieDetailCell" owner:self options:nil]lastObject];
    //电影图片
    [cell.movieImageButton sd_setBackgroundImageWithURL:[NSURL URLWithString:movie.imgUrlOfMovie] forState:(UIControlStateNormal) placeholderImage:[UIImage imageNamed:@"bg_movie_picker_placeholder"]];
    //单元格背景图片
    [cell.bgMovieImageView sd_setImageWithURL:[NSURL URLWithString:movie.imgUrlOfMovie] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        /** 添加模糊遮盖view*/
        UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        
        UIVisualEffectView *view = [[UIVisualEffectView alloc]initWithEffect:beffect];
        
        view.frame = cell.bgMovieImageView.bounds;
        
        [cell.bgMovieImageView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.right.bottom.left.mas_equalTo(0);
            
        }];
    }];

    //电影名字
    cell.movieNameLabel.text = movie.nameOfMovie;
    //电影评分
    float mark = [movie.markOfMovie floatValue];
    cell.markOfImageLabel.text = [NSString stringWithFormat:@"%.1f分",mark];
    //电影星星评分
    [cell configStarsWithMark:movie.markOfMovie];
    //电影版本图片
    cell.movieVersionImageView.image = [UIImage imageNamed:[FRMovie getVersionImageNameWithModel:movie]];
    //电影类型
    cell.movieTypeLabel.text = movie.typeOfMovie;
    //电影来源与时长
    cell.sourceAndDurLabel.text = [NSString stringWithFormat:@"%@/%@分钟",movie.movieDetail.sourceOfMovie,movie.durationOfMovie];
    //电影上映日期
    cell.showDateLabel.text = movie.dateOfShow;
    
    
    return cell;
    
}


- (void) configStarsWithMark:(NSNumber *)mark {
    int countOfFullStar = [mark floatValue] / 2;
    
    for (int i = 0; i < countOfFullStar; i ++) {
        UIImageView *starView = self.allStarImageView[i];
        starView.image = [UIImage imageNamed:@"star_movieComment_Score_full"];
    }
    
    float leftMark = [mark floatValue] - countOfFullStar * 2;
    if (leftMark >= 1 && countOfFullStar < 5) {
        UIImageView *starView = self.allStarImageView[countOfFullStar];
        starView.image = [UIImage imageNamed:@"star_movieComment_Score_half"];
    }

}
- (IBAction)clickWantToSeeBtn:(UIButton *)sender {
    sender.selected = !sender.isSelected;
}
@end
