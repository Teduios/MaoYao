//
//  FRScrollView.m
//  Demo跳转测试
//
//  Created by tarena032 on 16/1/11.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRScrollView.h"

#import "UIView+Extension.h"
@implementation FRScrollView

+(UIScrollView *)creatScrollViewWithFrame:(CGRect)frame WithContents:(NSArray<UIView *> *)contentArray AndViewWidth:(CGFloat)viewWidth{
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:frame];
    scrollView.contentSize = CGSizeMake(viewWidth * contentArray.count, frame.size.height);
    for (int i = 0; i < contentArray.count; i++) {
        UIView *view = contentArray[i];
        view.frame = CGRectMake(viewWidth * i, 0, viewWidth, frame.size.height);
        [scrollView addSubview:view];
    }
    scrollView.showsHorizontalScrollIndicator = NO;
    return scrollView;
}

@end
