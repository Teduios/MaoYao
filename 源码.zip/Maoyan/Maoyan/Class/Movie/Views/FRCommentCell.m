//
//  FRCommentCell.m
//  Maoyan
//
//  Created by tarena032 on 16/2/17.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCommentCell.h"
#import "UIImageView+WebCache.h"

@implementation FRCommentCell


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

/** 重写commenter的setter方法，在setter时将对应值赋值到cell的各个属性上*/
- (void)setCommenter:(FRCommenter *)commenter {
    _commenter = commenter;
    self.backgroundColor = [UIColor clearColor];
    /** 设置cell的背景图*/
    UIImageView *backgroundView = [[UIImageView alloc]initWithFrame:self.bounds];
    backgroundView.image = [UIImage imageNamed:@"cell_single"];
    self.backgroundView = backgroundView;
    UIImageView *selectedBackgroundView = [[UIImageView alloc]initWithFrame:self.bounds];
    selectedBackgroundView.image = [UIImage imageNamed:@"cell_single_selected"];

    self.selectedBackgroundView = selectedBackgroundView;
    
    /** 赋值cell*/
    //评分
    [self configStarsWithMark:self.commenter.score];
    //头像并设为圆形
    [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:self.commenter.avatarurl] placeholderImage:[UIImage imageNamed:@"DefaultProfileHead"]];
    self.headerImageView.layer.cornerRadius = 10;
    self.headerImageView.layer.masksToBounds = YES;
    //时间
    NSRange range = {5,5};
    self.timeLabel.text = [commenter.time substringWithRange:range];
    //评论内容
    self.contentLabel.text = commenter.content;
    //昵称
    self.nickNameLabel.text = commenter.nickName;
    //点赞数
    self.approveCountLabel.text = [NSString stringWithFormat:@"%@",commenter.approve];
    //评论数
    self.commentCountLabel.text = [NSString stringWithFormat:@"%@",commenter.reply];
}

/** 处理评分对应的星星*/
- (void) configStarsWithMark:(NSNumber *)mark {
    /** 将所有星星都替换为未评分状态*/
    for (UIImageView *imageView in self.startCommentImageView) {
        imageView.image = [UIImage imageNamed:@"star_movieComment_Score_empty"];
    }
    /** 根据score设置星星*/
    int i = 0;
    int score = [mark intValue];
    for (; i < score; i++) {
        UIImageView *imageView = self.startCommentImageView[i];
        imageView.image = [UIImage imageNamed:@"star_movieComment_Score_full"];
    }
    if (score < [mark floatValue]) {
        UIImageView *imageView = self.startCommentImageView[i];
        imageView.image = [UIImage imageNamed:@"star_movieComment_Score_half"];
    }
}

/** 点击点赞按钮*/
- (IBAction)clickApproveBtn:(UIButton *)sender {
    sender.selected = !sender.isSelected;
    int count = [self.commenter.approve intValue];
    if (sender.selected) {
        self.approveCountLabel.text = [NSString stringWithFormat:@"%d",count+1];
    }else {
       self.approveCountLabel.text = [NSString stringWithFormat:@"%d",count];
    }
}
@end
