//
//  FRScrollView.h
//  Demo跳转测试
//
//  Created by tarena032 on 16/1/11.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRScrollView : UIScrollView
/**
 创建一个滚动视图
 参数：
    滚动视图的frame
    滚动视图的内容存放在数组中
    滚动视图中内容的宽
 */
+(UIScrollView *)creatScrollViewWithFrame:(CGRect)frame WithContents:(NSArray<UIView*>*)contentArray AndViewWidth:(CGFloat)viewWidth;
@end
