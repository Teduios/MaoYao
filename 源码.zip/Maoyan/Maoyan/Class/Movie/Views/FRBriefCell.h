//
//  FRBriefCell.h
//  Maoyan
//
//  Created by tarena032 on 16/2/16.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRBriefCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *briefLabel;

@end
