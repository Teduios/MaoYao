//
//  FRMovieCell.h
//  电影购票
//
//  Created by tarena010 on 16/1/7.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FRMovie.h"
/**
 电影单元格
 显示在表视图中电影的信息
 */
@interface FRMovieCell : UITableViewCell

+ (FRMovieCell *)getMovieCellWithMovieModel:(FRMovie *)movie;


@end
