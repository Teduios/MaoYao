//
//  FRCommentCell.h
//  Maoyan
//
//  Created by tarena032 on 16/2/17.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FRCommenter.h"
@interface FRCommentCell : UITableViewCell
/** 评论者的模型*/
@property (nonatomic ,strong) FRCommenter *commenter;

@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *startCommentImageView;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *nickNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *commentCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *approveCountLabel;
- (IBAction)clickApproveBtn:(UIButton *)sender;

@end
