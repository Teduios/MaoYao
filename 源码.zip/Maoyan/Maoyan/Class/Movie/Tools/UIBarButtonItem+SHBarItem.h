//
//  UIBarButtonItem+SHBarItem.h
//  SearchDeal
//
//  Created by tarena032 on 16/1/21.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (SHBarItem)
@property (nonatomic ,strong) NSString *button;
//给定图片名字，action，target;返回UIBarButtonItem
+ (UIBarButtonItem *)barButtonItemWithImage:(NSString *)imageName withHighlightedImage:(NSString *)hlImageName withTarget:(id)target withAction:(SEL)action;

@end
