//
//  UIBarButtonItem+SHBarItem.m
//  SearchDeal
//
//  Created by tarena032 on 16/1/21.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "UIBarButtonItem+SHBarItem.h"


@implementation UIBarButtonItem (SHBarItem)

+ (UIBarButtonItem *)barButtonItemWithImage:(NSString *)imageName withHighlightedImage:(NSString *)hlImageName withTarget:(id)target withAction:(SEL)action {
    UIButton *button = [UIButton new];
    [button setImage:[UIImage imageNamed:imageName] forState:(UIControlStateNormal)];
    [button setImage:[UIImage imageNamed:hlImageName] forState:(UIControlStateHighlighted)];
    [button addTarget:target action:action forControlEvents:(UIControlEventTouchUpInside)];
    button.frame = CGRectMake(0, 0, 60, 40);
    //button.backgroundColor = [UIColor redColor];
    return [[UIBarButtonItem alloc]initWithCustomView:button];
}

@end
