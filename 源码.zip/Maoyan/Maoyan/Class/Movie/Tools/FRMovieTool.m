//
//  FRMovieTool.m
//  Demo跳转测试
//
//  Created by tarena032 on 16/1/14.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRMovieTool.h"
#import "FRMovie.h"
#import "FRNetworkManager.h"
@implementation FRMovieTool

+(NSArray *)getAllMovieData:(NSDictionary *)dataDic{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *movieDic in dataDic[@"movies"]) {
        [mutableArray addObject:[FRMovie parseJSON:movieDic] ];
    }
    return [mutableArray copy];
}

+ (void)getAllMovieDataWithUrlString:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successGetBlock)success failure:(failureGetBlock)failure {

    [FRNetworkManager sendGetRequestWithUrl:urlStr parameters:paraDic success:^(id responseObject) {
        NSArray *movieArray = [FRMovieTool getAllMovieData:responseObject[@"data"]];
        //成功
        MYLog(@"获取热映电影首页数据成功");
        success(movieArray);
    } failure:^(NSError *error) {
        failure(error);
    }];
}

+ (void)getMovieDetailWithMovie:(FRMovie *)movie success:(successGetDetailBlock)success failure:(failureGetBlock)failure {
    NSString *urlStr = [NSString stringWithFormat:@"http://m.maoyan.com/movie/%@.json",movie.idOfMovie];
    [FRNetworkManager sendGetRequestWithUrl:urlStr parameters:nil success:^(id responseObject) {
        movie.movieDetail = [FRMovieDetail parseJSON:responseObject[@"data"][@"MovieDetailModel"]];
    success(movie);
    } failure:^(NSError *error) {
        //
        failure(error);
    }];
}




@end
