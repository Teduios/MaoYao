//
//  FRNetworkManager.h
//  Maoyan
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef void(^successBlock)(id responseObject);
typedef void(^failureBlock)(NSError *error);

/**
 对网络请求的处理
 */
@interface FRNetworkManager : NSObject
/**
 发送get请求，成功返回所有json对象responseObject
 */
+ (void)sendGetRequestWithUrl:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successBlock)success failure:(failureBlock)failure;

@end
