//
//  FRNetworkManager.m
//  Maoyan
//
//  Created by tarena032 on 16/1/28.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRNetworkManager.h"
#import "AFHTTPSessionManager.h"

@implementation FRNetworkManager

+(void)sendGetRequestWithUrl:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successBlock)success failure:(failureBlock)failure{
    
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    [manger GET:urlStr parameters:paraDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
}

@end
