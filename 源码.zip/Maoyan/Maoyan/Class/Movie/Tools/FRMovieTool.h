//
//  FRMovieTool.h
//  Demo跳转测试
//
//  Created by tarena032 on 16/1/14.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FRMovieDetail.h"
#import "FRMovie.h"

typedef void(^successGetBlock)(NSArray  *allMovieArray);
typedef void(^failureGetBlock)(NSError *error);
typedef void(^successGetDetailBlock)(FRMovie *movie);

@interface FRMovieTool : NSObject

/**
 获得所有的电影信息存放到一个字典中返回
 参数：传入电影首页的url信息，成功返回电影数组
 */

+ (void)getAllMovieDataWithUrlString:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successGetBlock)success failure:(failureGetBlock)failure;

/**
 需求：获取包含详细信息的电影对象
 */
+ (void)getMovieDetailWithMovie:(FRMovie *)movie success:(successGetDetailBlock)success failure:(failureGetBlock)failure;



@end
