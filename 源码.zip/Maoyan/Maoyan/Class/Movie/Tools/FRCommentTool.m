//
//  FRCommentTool.m
//  Maoyan
//
//  Created by tarena032 on 16/2/16.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCommentTool.h"
#import "FRCommenter.h"
#import "FRNetworkManager.h"

@implementation FRCommentTool

+ (void)getAllCommentData:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successCommentBlock)success failure:(failureCommentBlock)failure {
    [FRNetworkManager sendGetRequestWithUrl:urlStr parameters:paraDic success:^(id responseObject) {
        NSDictionary *allCommentDic = responseObject[@"data"][@"CommentResponseModel"];
        FRCommentGroup *allComments = [[FRCommentGroup alloc]init];
        for (NSDictionary *dic in allCommentDic[@"hcmts"]) {
            FRCommenter *commenter = [[FRCommenter alloc]init];
            [commenter setValuesForKeysWithDictionary:dic];
            [allComments.hcmts addObject:commenter];
        }
        for (NSDictionary *dic in allCommentDic[@"cmts"]) {
            FRCommenter *commenter = [[FRCommenter alloc]init];
            [commenter setValuesForKeysWithDictionary:dic];
            [allComments.cmts addObject:commenter];
        }
        success(allComments);
        
    } failure:^(NSError *error) {
        failure(error);
    }];
}

@end
