//
//  FRCommentTool.h
//  Maoyan
//
//  Created by tarena032 on 16/2/16.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FRCommentGroup.h"

typedef void(^successCommentBlock)(FRCommentGroup  *comments);
typedef void(^failureCommentBlock)(NSError *error);

@interface FRCommentTool : NSObject

/**
 获得所有的电影的相关评论信息通过block返回
 参数：传入含电影id的url信息，成功返回电影数组
 */

+ (void)getAllCommentData:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successCommentBlock)success failure:(failureCommentBlock)failure;

@end
