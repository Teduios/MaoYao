//
//  FRCityGroup.h
//  WeatherForecast
//
//  Created by tarena010 on 16/1/18.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FRCityGroup : NSObject
@property (nonatomic, strong) NSArray *cities;
@property (nonatomic, strong) NSString *title;
@end
