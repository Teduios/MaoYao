//
//  FRCityGroup.m
//  WeatherForecast
//
//  Created by tarena010 on 16/1/18.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "FRCityGroup.h"

@implementation FRCityGroup

@end
