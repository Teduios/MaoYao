//
//  TRLocationManager.h
//  WeatherForecast
//
//  Created by tarena010 on 16/1/18.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

//typedef  void(^saveLocationBlock)(double lat,double lon);

@interface FRLocationManager : NSObject

+(void)getUserLocation:(void(^)(double lat,double lon))locationBlock;
//等同于 (void)getUserLocation:(saveLocationBlock)locationBlock;

@end
