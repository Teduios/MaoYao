//
//  TRLocationManager.m
//  WeatherForecast
//
//  Created by tarena010 on 16/1/18.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "FRLocationManager.h"
#import <UIKit/UIKit.h>

@interface FRLocationManager ()<CLLocationManagerDelegate>
@property(nonatomic,strong) CLLocationManager * manager;
@property(nonatomic,copy)void(^saveLocationBlock)(double lat,double lon);
@end

@implementation FRLocationManager
//单例：一个类的唯一一个实例对象
+ (id)sharedLocationManager {
    static FRLocationManager *locationManager = nil;
    if (!locationManager) {
        locationManager = [[FRLocationManager alloc]init];
    }
    return locationManager;
}

//重写init方法初始化manager对象/征求用户同意
-(instancetype)init{
    if (self = [super init]) {
        self.manager = [[CLLocationManager alloc]init];
        self.manager.delegate = self;
        if ([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0) {
            [self.manager requestWhenInUseAuthorization];
        }
    }
    return self;
}

+(void)getUserLocation:(void (^)(double, double))locationBlock{
    FRLocationManager *locationManager = [FRLocationManager sharedLocationManager];
    [locationManager getUserLocations:locationBlock];
}

-(void)getUserLocations:(void (^)(double, double))locationBlock{
    //用户没有同意/没有开启定位功能
    if (![CLLocationManager locationServicesEnabled]) {
        MYLog(@"无法定位");
        return;
    }
    //!!!将saveLocationBlock赋值给locationBlock
    _saveLocationBlock = [locationBlock copy];
    //设定精度（调用频率）
    self.manager.distanceFilter = 500;
    //同意/开启 -> 开始定位
    [self.manager startUpdatingLocation];
}

#pragma mark - ManagerDelegate
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    //防止多次调用
    //经纬度
    CLLocation *location = [locations lastObject];
    //block传参（调用block）
    self.saveLocationBlock(location.coordinate.latitude,location.coordinate.longitude);
    
    [self.manager stopUpdatingLocation];
}


















@end
