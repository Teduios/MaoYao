//
//  FRMainTabBarViewController.m
//  猫妖
//
//  Created by tarena010 on 16/1/13.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import "FRMainTabBarViewController.h"
#import "FRMovieViewController.h"
#import "SHNavViewController.h"

@interface FRMainTabBarViewController ()

@end

@implementation FRMainTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITabBar *bar = [UITabBar appearance];
    [bar setTintColor:[UIColor redColor]];
    [bar setBackgroundImage:[UIImage imageNamed:@"tabbar_background"]];
    
    FRMovieViewController *movieVC = [FRMovieViewController new];
    SHNavViewController *movieNavi = [[SHNavViewController alloc]initWithRootViewController:movieVC];
    movieNavi.tabBarItem.image = [UIImage imageNamed:@"movie"];
    movieNavi.tabBarItem.selectedImage = [UIImage imageNamed:@"movie_on"];
    movieNavi.tabBarItem.title = @"电影";
    
    
    SHNavViewController *cinemaNavi = [[UIStoryboard storyboardWithName:@"Cinema" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
    cinemaNavi.navigationItem.title = @"影院";
    cinemaNavi.tabBarItem.title = @"影院";
    cinemaNavi.tabBarItem.image = [UIImage imageNamed:@"cinema"];
    cinemaNavi.tabBarItem.selectedImage = [UIImage imageNamed:@"cinema_on"];
    
    SHNavViewController *discoverNavi = [[UIStoryboard storyboardWithName:@"discover" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
    discoverNavi.tabBarItem.title = @"发现";
    discoverNavi.tabBarItem.image = [UIImage imageNamed:@"forum"];
    discoverNavi.tabBarItem.selectedImage = [UIImage imageNamed:@"forum_on"];
    
     SHNavViewController *mineNaviController = [[UIStoryboard storyboardWithName:@"AboutMe" bundle:[NSBundle mainBundle]] instantiateInitialViewController];
    mineNaviController.tabBarItem.title = @"我的";
    mineNaviController.tabBarItem.image = [UIImage imageNamed:@"mine"];
    mineNaviController.tabBarItem.selectedImage = [UIImage imageNamed:@"mine_on"];
    self.viewControllers = @[movieNavi,cinemaNavi,discoverNavi,mineNaviController];
    
   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
