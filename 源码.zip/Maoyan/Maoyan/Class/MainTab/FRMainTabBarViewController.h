//
//  FRMainTabBarViewController.h
//  猫妖
//
//  Created by tarena010 on 16/1/13.
//  Copyright © 2016年 tarena010. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 主要的tabBar界面控制器
 所有的控制器由该控制器控制
*/
@interface FRMainTabBarViewController : UITabBarController

@end
