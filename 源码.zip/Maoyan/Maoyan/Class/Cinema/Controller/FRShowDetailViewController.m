//
//  ViewController.m
//  选电影
//
//  Created by tarena on 16/2/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "FRShowDetailViewController.h"
#import "YXFilmSelectView.h"
#import "ALLTheaterTool.h"
#import "movieDetail.h"
#import "AFNetworking.h"
#import "RequsetTool.h"
#import "MovieTableViewCell.h"
#import "MovieTime.h"
#import "FRBuyTicketViewController.h"
#import "FRCinemaLocationViewController.h"

#define SCREEN_WIDTH    [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT    [[UIScreen mainScreen] bounds].size.height
@interface FRShowDetailViewController ()<UIScrollViewDelegate,YXFilmSelectViewDelegate,UITableViewDelegate,UITableViewDataSource>
/** 电影图片*/
@property (weak, nonatomic) IBOutlet UIView *showView;

@property(nonatomic,strong)UILabel *showLabel;
@property(nonatomic,strong)UIView *containerView;
/**电影时间*/
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;
@property(nonatomic,assign)NSInteger number;
/** 当天上映电影*/
@property(nonatomic,strong)NSArray *movieArray;
/**电影时间列表*/
@property(nonatomic,strong)NSArray *timeArray;
@property (nonatomic ,strong) movieDetail *selectedMovie;
/** 影院名称*/
@property (weak, nonatomic) IBOutlet UILabel *cinemaNameLabel;
/** 影院地址*/
@property (weak, nonatomic) IBOutlet UILabel *cinemaAddressLabel;
//电影名字
@property (weak, nonatomic) IBOutlet UILabel *movieName;
//电影时长
@property (weak, nonatomic) IBOutlet UILabel *movieType;
//电影评分
@property (weak, nonatomic) IBOutlet UILabel *movieGrade;


//当天日期
@property (nonatomic ,strong) NSString *currentDateStr;
@end

@implementation FRShowDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self getMovieData];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
}
#pragma mark - 私有方法
//获取数据
-(void)getMovieData
{
   //获取当前日期
    NSDate *currentDate = [[NSDate alloc]init];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
   
//    NSTimeZone *zone = [NSTimeZone systemTimeZone];//格式
//    NSInteger interval = [zone secondsFromGMTForDate:[[NSDate alloc]init]];
//    currentDate = [currentDate dateByAddingTimeInterval:interval];
     NSString *dateStr = [dateFormatter stringFromDate:currentDate];
    self.currentDateStr = dateStr;
    [MBProgressHUD showMessage:@"加载数据中\n请稍后" toView:self.view];
   [RequsetTool getAllTheatereDataWithUrlString:[NSString stringWithFormat:@"http://platform.mobile.meituan.com/open/maoyan/v1/cinema/%@/shows.json?dt=%@",self.theater.brdId,dateStr] parameters:nil success:^(id respond) {
       [MBProgressHUD hideHUDForView:self.view animated:YES];
       self.movieArray = [ALLTheaterTool getAllMovieDataWithRespond:respond];
       [self showMainView];
   } failure:^(NSError *error) {
       [MBProgressHUD showError:@"加载失败\n请检查网络"];
   }];
    
    
}
/** 显示界面*/
-(void)showMainView{
    NSMutableArray *allImageUrlArray = [[NSMutableArray alloc]init];
    for (int i=0; i<self.movieArray.count; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.png",i+1]];
        self.bgImageView.image = image;
        [allImageUrlArray addObject:image];
    }
    YXFilmSelectView *filmSelectView =[[YXFilmSelectView alloc]initViewWithImageArray:allImageUrlArray];
    filmSelectView.delegate =self;
    //    self.showView = filmSelectView;
    [self.showView addSubview:filmSelectView];
    self.tableView.delegate =self;
    self.tableView.dataSource =self;
    [self setShowViewBg];
    [self itemSelected:0];
}
/** 设置滚动视图的背景*/
- (void)setShowViewBg {
    //单元格背景图片
    
    /** 添加模糊遮盖view*/
    UIBlurEffect *beffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        
    UIVisualEffectView *view = [[UIVisualEffectView alloc]initWithEffect:beffect];
        
    view.frame = self.bgImageView.bounds;
    
    [self.bgImageView addSubview:view];


}

//移动图片时刷新电影资料
-(void)itemSelected:(NSInteger)index
{
    self.number = index;
    movieDetail *movie = self.movieArray[index];
    self.selectedMovie = movie;
    
    NSMutableArray *timeArray = [NSMutableArray array];
    for (NSDictionary *dic in movie.timeArray) {
        if ([dic[@"sell"] boolValue]) {
            [timeArray addObject:dic];
        }
    }
    self.timeArray = [timeArray copy];
    self.movieName.text = movie.nm;
    self.movieType.text = [NSString stringWithFormat:@"片长:%@分钟",movie.dur];
    self.movieGrade.text = [NSString stringWithFormat:@"%@分",movie.sc];;
    self.cinemaNameLabel.text = self.theater.brd;
    self.cinemaAddressLabel.text = self.theater.addr;
    //    self.cinemaAddressLabel.text =
    //刷新表示图
    [self.tableView reloadData];
}

/** 计算散场时间*/
- (NSString *)getEndTimeWithStartTime:(NSString *)startTime AndDuration:(NSNumber *)duration{
    //将字符串时间转为时间类型
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"HH:mm"];
    NSDate *startDate = [dateFormatter dateFromString:startTime];
    NSTimeInterval startInterval = [startDate timeIntervalSince1970];
    NSTimeInterval endInterval = startInterval + [duration doubleValue]*60;
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:endInterval];
    
    NSTimeZone *zone = [NSTimeZone systemTimeZone];//格式
    NSInteger interval = [zone secondsFromGMTForDate:[[NSDate alloc]init]];
    endDate = [endDate dateByAddingTimeInterval:interval];
    
    //NSLog(@"%@ -> %@",startTime,endDate);
    
    NSString *endTime = [NSString stringWithFormat:@"%@",endDate];
    NSRange range = {11,5};
    endTime = [endTime substringWithRange:range];
    return [NSString stringWithFormat:@"%@散场",endTime];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showMapSegue"]) {
        FRCinemaLocationViewController *locationController = segue.destinationViewController;
        locationController.theater = sender;
    }
}
#pragma mark - 用户交互动作
/** 点击返回按钮*/
- (IBAction)backClick:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (IBAction)clickLocationBtn:(id)sender { MYLog(@"tap");
    [self performSegueWithIdentifier:@"showMapSegue" sender:self.theater];
}
/** 点击定位图片手势*/
- (void)tapGestureOnLocationImage:(UITapGestureRecognizer *)sender {
    MYLog(@"tap");
    [self performSegueWithIdentifier:@"showMapSegue" sender:self.theater];
}
#pragma mark - 协议
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.timeArray.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   MovieTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell22"];
    /** 设置cell属性*/
    [cell setBackground];
    NSDictionary *dic = self.timeArray[indexPath.row];
    MovieTime *time = [MovieTime getMovieTimeWithJson:dic];
    cell.startTime.text = time.tm;
    [cell.startTime setFont:[UIFont fontWithName:@"DBLCDTempBlack" size:19]];
    cell.endTime.text = [self getEndTimeWithStartTime:time.tm AndDuration:self.selectedMovie.dur];
    cell.language.text = [NSString stringWithFormat:@"%@%@",time.lang,time.tp];
    cell.room.text = time.room;
    cell.discountPriceLabel.text = time.sellPr;
    cell.originPriceLabel.text = [NSString stringWithFormat:@"影院价%@元",time.pr];
    /** 区分是否可以购买*/
    if (![time.isSell boolValue]) {
        [cell.buyTicketBtn setBackgroundImage:[UIImage imageNamed:@"reserve_gray_btn"] forState:(UIControlStateNormal)];
        [cell.buyTicketBtn setBackgroundImage:[UIImage imageNamed:@"reserve_gray_btn_pressed"] forState:(UIControlStateHighlighted)];
        [cell.buyTicketBtn setTitle:@"停止售票" forState:(UIControlStateNormal)];
        [cell.buyTicketBtn setTitleColor:[UIColor grayColor] forState:(UIControlStateNormal)];
    }else {
        cell.buyTicketBtn.enabled = YES;
        [cell.buyTicketBtn setBackgroundImage:[UIImage imageNamed:@"reserve_btn"] forState:(UIControlStateNormal)];
        [cell.buyTicketBtn setBackgroundImage:[UIImage imageNamed:@"reserve_btn_pressed"] forState:(UIControlStateHighlighted)];
        [cell.buyTicketBtn setTitle:@"选购售票" forState:(UIControlStateNormal)];
        [cell.buyTicketBtn setTitleColor:[UIColor redColor] forState:(UIControlStateNormal)];
    }
  
    
    return cell;
}

//点击购买
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dic = self.timeArray[indexPath.row];
    MovieTime *movieTime = [MovieTime getMovieTimeWithJson:dic];
    FRBuyTicketViewController *buyTicketVC = [[FRBuyTicketViewController alloc]init];
    buyTicketVC.movieTime = movieTime;

    NSString *url = [NSString stringWithFormat:@"http://m.maoyan.com/#tmp=seats&showId=%@&showDate=%@&cname=%@",movieTime.showId,self.currentDateStr,self.theater.brd];
    buyTicketVC.movieTime.seatUrl = url;

    
    [self.navigationController pushViewController:buyTicketVC animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
