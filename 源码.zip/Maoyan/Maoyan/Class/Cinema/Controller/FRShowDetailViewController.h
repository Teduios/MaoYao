//
//  ViewController.h
//  选电影
//
//  Created by tarena on 16/2/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Theater.h"

@interface FRShowDetailViewController : UIViewController
@property(nonatomic,strong)Theater *theater;

@end

