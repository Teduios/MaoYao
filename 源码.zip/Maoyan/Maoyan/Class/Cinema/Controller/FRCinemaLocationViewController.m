//
//  FRCinemaLocationViewController.m
//  Maoyan
//
//  Created by tarena032 on 16/2/29.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCinemaLocationViewController.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "UIBarButtonItem+SHBarItem.h"
#import "FRAnnotation.h"

@interface FRCinemaLocationViewController ()<MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic ,strong) CLLocationManager *manager;
@end

@implementation FRCinemaLocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = self.theater.brd;
    self.manager = [CLLocationManager new];
    //请求定位，假定用户同意按钮
    [self.manager requestWhenInUseAuthorization];
    self.mapView.delegate = self;
    //开始定位
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
    self.mapView.rotateEnabled = NO;
    //设置地图类型
    self.mapView.mapType = MKMapTypeStandard;
    MYLog(@"%@,%@",self.theater.lat,self.theater.lng);
    [self addAnnotation];
}


/** 添加大头针对象*/
- (void) addAnnotation {
    FRAnnotation *annotation = [FRAnnotation new];
    CLLocationDegrees latitude = [self.theater.lat doubleValue];
    CLLocationDegrees longitude = [self.theater.lng doubleValue];
    annotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
    annotation.title = self.theater.brd;
    annotation.subtitle = self.theater.addr;
    annotation.image = [UIImage imageNamed:@"icon_paopao_waterdrop_streetscape"];
    //挪动地图到添加大头针的位置（设置region）
    self.mapView.region = MKCoordinateRegionMake(annotation.coordinate, MKCoordinateSpanMake(0.001, 0.001));
    //添加到地图上
    [self.mapView addAnnotation:annotation];
}

/** 返回按钮*/
- (IBAction)clickBackItem:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 协议
//设置大头针的动画和颜色
//调用时机：当addAnnotation被调用时就调用
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    //需求：修改默认的大头针图片
    
    //判断添加的Annotation是否是默认的蓝色圈
    if ([annotation isMemberOfClass:[MKUserLocation class]]) {
        return nil;
    }
    static NSString *identifier = @"annotation";
    MKAnnotationView *annoView = [mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annoView) {
        annoView = [[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:identifier];
        //Ver1 annoView.image = [UIImage imageNamed:@"icon_paopao_waterdrop_streetscape"];
        
        //Ver2
        FRAnnotation *anno = (FRAnnotation *)annotation;
        annoView.image = anno.image;
        //设置弹出框的左右视图
       // annoView.leftCalloutAccessoryView = [[UISwitch alloc]init];
        annoView.rightCalloutAccessoryView = [UIButton buttonWithType:(UIButtonTypeDetailDisclosure)];
        annoView.canShowCallout = YES;
    }else{
        annoView.annotation = annotation;
    }
    
    return annoView;
}



@end
