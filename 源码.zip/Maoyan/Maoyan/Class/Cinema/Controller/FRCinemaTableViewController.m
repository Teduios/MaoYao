//
//  FRCinemaTableViewController.m
//  Maoyan
//
//  Created by tarena032 on 16/2/25.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCinemaTableViewController.h"
#import "ALLTheaterTool.h"
#import "Theater.h"
#import "RequsetTool.h"
#import "FRTheaterCell.h"
#import "FRShowDetailViewController.h"
#import "FRCinemaCell.h"
#import "UIBarButtonItem+SHBarItem.h"

#import "SHAutoScrollView.h"
#import "FRLocationManager.h"
#import "FRSearchTableViewController.h"
#import "SHNavViewController.h"
#import "FRCityGroupTableViewController.h"

@interface FRCinemaTableViewController ()<SHScrollViewViewDelegate>{
    NSString *_cityName;
}

@property(nonatomic,strong)NSArray *allCinemaArray;
@property (nonatomic ,assign) BOOL option;
@end

@implementation FRCinemaTableViewController

- (void)setOption:(BOOL)option {
    if (!option) {
        _option = NO;
    }else
        _option = option;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 80;
    [self setHeaderViewAD];
    //监听
    [self listenNotification];

    [self showGoBackItem:self.option];
    /**开始定位*/
    [self getLocation];
}


#pragma mark - 通知，改变城市
-(void)listenNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(listenChangeCity:) name:@"DidCityChange" object:nil];
}

-(void)listenChangeCity:(NSNotification*)notification{
    //获取传过来的参数
    NSString *cityName = notification.userInfo[@"CiytName"];
    _cityName = cityName;
    [self setNavBarItem];
    //重新发请求 q = 上海 -> q = shanghai
    //    [self sendRequestToServer:cityName];
}

- (void)setNavBarItem {
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    UIButton *btn = [UIButton new];
    btn.frame = CGRectMake(-40, 0, 50, 25);
    if (!_cityName) {
        _cityName = @"杭州";
    }
    [btn setTitle:_cityName forState:(UIControlStateNormal)];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    
    [btn setImage:[UIImage imageNamed:@"ic_moreInfo_arrowDown"] forState:(UIControlStateNormal)];
    UIBarButtonItem *leftBarBtn = [[UIBarButtonItem alloc]initWithCustomView:btn];
    [btn addTarget:self action:@selector(chooseCity) forControlEvents:(UIControlEventTouchUpInside)];
    self.navigationItem.leftBarButtonItem = leftBarBtn;
    
    UIBarButtonItem *rightBatBtn = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"icon_search_glass"] style:(UIBarButtonItemStylePlain) target:self action:@selector(search)];
    self.navigationItem.rightBarButtonItem = rightBatBtn;
}

- (void)chooseCity {
    FRCityGroupTableViewController *cityVC = [FRCityGroupTableViewController new];
    SHNavViewController *navi = [[SHNavViewController alloc]initWithRootViewController:cityVC];
    [self presentViewController:navi animated:YES completion:nil];
}

- (void)search {
    FRSearchTableViewController *searchVC = [FRSearchTableViewController new];
    SHNavViewController *navi = [[SHNavViewController alloc]initWithRootViewController:searchVC];
    [self presentViewController:navi animated:YES completion:nil];
}

#pragma mark - 定位
-(void)getLocation{
    [FRLocationManager getUserLocation:^(double lat, double lon) {
        CLLocation *location = [[CLLocation alloc]initWithLatitude:lat longitude:lon];
        [self getCityName:location];
    }];
}

//反地理编码
-(void)getCityName:(CLLocation*)location{
    CLGeocoder *geocoder = [CLGeocoder new];
    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (!error) {
            CLPlacemark *placemark = [placemarks lastObject];
            NSString *str = placemark.addressDictionary[@"City"];
            _cityName = [str substringToIndex:[str length] - 1];
        }else{
            [MBProgressHUD showError:@"定位失败"];
        }
    }];
}


#pragma mark - Lazy Load
- (NSArray *)allCinemaArray {
    if (!_allCinemaArray) {
        [MBProgressHUD showMessage:@"加载数据中\n请稍后" toView:self.tableView];
        [RequsetTool getAllTheatereDataWithUrlString:@"http://m.maoyan.com/cinemas.json" parameters:nil success:^(id respond) {
            [MBProgressHUD hideAllHUDsForView:self.tableView animated:YES];
            _allCinemaArray = [ALLTheaterTool getAllTheaterDataWithString:@"江干区" and:respond];
            //[MBProgressHUD showError:@"加载成功"];
            [self.tableView reloadData];
        } failure:^(NSError *error) {
            [MBProgressHUD showError:@"加载失败\n请检查网络"];
        }];

    }
    return _allCinemaArray;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;

}

/** 准备跳转*/
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showDetailSegue"]) {
        id destVC = segue.destinationViewController;
        if ([destVC isKindOfClass:[FRShowDetailViewController class]]) {
            FRShowDetailViewController *vc = (FRShowDetailViewController *)destVC;
            vc.theater = (Theater *)sender;
        }
    }
    [super prepareForSegue:segue sender:sender];
}
#pragma mark - 私有方法
/** 是否显示返回按钮*/
- (void)showGoBackItem:(BOOL)option {
    self.option = option;
    if (self.option) {
        self.navigationItem.leftBarButtonItem = [UIBarButtonItem barButtonItemWithImage:@"btn_backItem" withHighlightedImage:@"btn_backItem_highlighted" withTarget:self withAction:@selector(goBack)];
    }else {
        /** 设置左右按钮*/
        [self setNavBarItem];
    }
}
- (void)goBack {
    [self dismissViewControllerAnimated:YES completion:nil];
}

/**设置表头视图广告*/
- (void)setHeaderViewAD {
    /** 创建滚动视图*/
    SHAutoScrollView *scrollView = [[SHAutoScrollView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 60)];
    scrollView.delegate = self;
    /** 添加图片*/
    NSArray *imageNameArray = @[@"ad1.jpg",@"ad2.jpg",@"ad3.jpg",@"ad4.jpg",@"ad5.jpg",@"ad6.jpg",@"ad7.jpg",@"ad8.jpg"];
    NSMutableArray *imageViewArray = [NSMutableArray array];
    for (NSString *imageName in imageNameArray) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.image = [UIImage imageNamed:imageName];
        //imageView.contentMode = UIViewContentModeScaleAspectFit;
        [imageViewArray addObject:imageView];
    }
    [scrollView setImageViewAry:imageViewArray];
    /** 滚动循环时间间隔（必须先设置）*/
    scrollView.timeInterval = 3;
    /** 是否滚动*/
    [scrollView shouldAutoShow:YES];
    self.tableView.tableHeaderView = scrollView;
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allCinemaArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FRCinemaCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cinemaCell"];
    if (!cell) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"FRCinemaCell" owner:self options:nil] lastObject];
    }
    Theater *theater = self.allCinemaArray[indexPath.row];
    cell.theater = theater;
    
    // Configure the cell...
    
    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self performSegueWithIdentifier:@"showDetailSegue" sender:self.allCinemaArray[indexPath.row]];
}
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (void)dealloc {
    NSLog(@"guale");
}

@end
