//
//  FRTheaterCell.m
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "FRTheaterCell.h"

@implementation FRTheaterCell

- (void)setTheater:(Theater *)theater {
    _theater = theater;
    self.address.text = theater.addr;
    self.price.text = [NSString stringWithFormat:@"%@元起",theater.sellPrice];
    self.theaterName.text = theater.brd;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
