//
//  MovieTableViewCell.h
//  选电影
//
//  Created by tarena on 16/2/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MovieTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *startTime;
@property (weak, nonatomic) IBOutlet UILabel *endTime;
@property (weak, nonatomic) IBOutlet UILabel *language;
@property (weak, nonatomic) IBOutlet UILabel *room;
@property (weak, nonatomic) IBOutlet UILabel *discountPriceLabel;

@property (weak, nonatomic) IBOutlet UIButton *buyTicketBtn;
@property (weak, nonatomic) IBOutlet UILabel *originPriceLabel;
@end
