//
//  MovieTableViewCell.m
//  选电影
//
//  Created by tarena on 16/2/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "MovieTableViewCell.h"

@implementation MovieTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
