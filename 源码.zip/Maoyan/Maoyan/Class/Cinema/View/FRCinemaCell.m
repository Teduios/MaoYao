//
//  FRCineaCell.m
//  Maoyan
//
//  Created by tarena032 on 16/2/24.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRCinemaCell.h"

@implementation FRCinemaCell
- (void)setTheater:(Theater *)theater {
    _theater = theater;
    [self setBackground];
    
    
    self.NameOfCinemaLabel.text = theater.brd;
    self.priceLabel.text = [NSString stringWithFormat:@"%@",theater.sellPrice];
    self.addressOfCinemaLabel.text = theater.addr;
    self.imaxImageView.hidden = ![theater.imax boolValue];
}

@end
