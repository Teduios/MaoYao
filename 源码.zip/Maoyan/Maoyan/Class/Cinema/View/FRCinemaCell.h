//
//  FRCineaCell.h
//  Maoyan
//
//  Created by tarena032 on 16/2/24.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Theater.h"
@interface FRCinemaCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *NameOfCinemaLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressOfCinemaLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imaxImageView;
@property (nonatomic ,strong) Theater *theater;
@end
