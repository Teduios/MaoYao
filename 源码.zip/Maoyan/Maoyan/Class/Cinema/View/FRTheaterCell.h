//
//  FRTheaterCell.h
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Theater.h"

@interface FRTheaterCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *theaterName;
@property (strong, nonatomic) Theater *theater;
@end
