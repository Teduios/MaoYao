//
//  movieDetail.h
//  选电影
//
//  Created by tarena on 16/2/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface movieDetail : NSObject
/**电影类型*/
@property(nonatomic,strong)NSString *cat ;
/**导演*/
@property(nonatomic,strong)NSString *dir;
/**电影屏幕类型 3d 、 2d*/
@property(nonatomic,strong)NSString *ver;
/**主演*/
@property(nonatomic,strong)NSString * star;
/**日期*/
@property(nonatomic,strong)NSString *dt;
/**开始时间*/
@property(nonatomic,strong)NSString *tm;
/**语言*/
@property(nonatomic,strong)NSString *lang;
/**播放厅*/
@property(nonatomic,strong)NSString * th;
/**电影名字*/
@property(nonatomic,strong)NSString *nm;
/**电影产地*/
@property(nonatomic,strong)NSString *src;
/**电影评分*/
@property(nonatomic,strong)NSString *sc;
/** 电影时长*/
@property (nonatomic ,strong) NSNumber *dur;

/**座右铭  什么b玩样儿*/
@property(nonatomic,strong)NSString *scm;
/** 电影图片*/
@property(nonatomic,strong)NSString *img;
/**电影时间表*/
@property(nonatomic,strong)NSArray *timeArray;

/**获取对象的方法*/
+(movieDetail*)parseDetailJson:(NSDictionary *)dic;

@end
