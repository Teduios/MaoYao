//
//  MovieTime.h
//  选电影
//
//  Created by tarena on 16/2/23.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieTime : NSObject

/**开始时间*/
@property(nonatomic,strong)NSString *tm;
/**语言*/
@property(nonatomic,strong)NSString *lang;
/** 电影版本*/
@property (nonatomic ,strong) NSString *tp;
/** 电影原价*/
@property (nonatomic ,strong) NSString *pr;
/** 电影现价*/
@property (nonatomic ,strong) NSString *sellPr;
/** 能否售票*/
@property (nonatomic ,getter=isSell) NSNumber *sell;
/** 放映Id*/
@property (nonatomic ,strong) NSNumber *showId;
/**电影播放厅*/
@property(nonatomic,strong)NSString *room;
/**电影选座*/
@property(nonatomic,strong) NSString *seatUrl;

+(MovieTime *) getMovieTimeWithJson:(NSDictionary*)dic;
@end
