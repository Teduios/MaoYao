//
//  movieDetail.m
//  选电影
//
//  Created by tarena on 16/2/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "movieDetail.h"

@implementation movieDetail
+(movieDetail*)parseDetailJson:(NSDictionary *)dic
{
    movieDetail *detail = [movieDetail new];
    detail.cat = dic[@"cat"];
    
    detail.nm = dic[@"nm"];
    detail.sc = dic[@"sc"];
//    detail.star = dic[@"star"];
//    detail.dt = dic[@"plist"][@"dt"];
    detail.img = dic[@"img"];
    detail.timeArray = dic[@"plist"];
    detail.dur = dic[@"dur"];

    
    return detail;



}


@end
