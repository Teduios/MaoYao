//
//  MovieTime.m
//  选电影
//
//  Created by tarena on 16/2/23.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "MovieTime.h"

@implementation MovieTime

+(MovieTime *)getMovieTimeWithJson:(NSDictionary *)dic
{
    MovieTime *time = [MovieTime new];
    time.tm = dic[@"tm"];
    time.lang = dic[@"lang"];
    time.pr =dic[@"pr"];
    time.room = dic[@"th"];
    time.sell = dic[@"sell"];
    time.sellPr = dic[@"sellPr"];
    time.tp = dic[@"tp"];
    time.seatUrl = dic[@"seatUrl"];
    time.showId = dic[@"showId"];
    return time;
}

@end
