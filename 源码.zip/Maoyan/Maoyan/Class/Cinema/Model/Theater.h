//
//  Theater.h
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Theater : NSObject

@property(nonatomic,strong)NSString *brd;//影院名字
@property(nonatomic,strong)NSString *addr;//影院地址
@property(nonatomic,strong)NSNumber *sellPrice;//起步价
@property(nonatomic,strong)NSNumber *brdId;
@property (nonatomic ,strong) NSNumber *lng;
@property (nonatomic ,strong) NSNumber *lat;
@property (nonatomic ,strong) NSNumber *imax;

+(Theater*)parseDailyJson:(NSDictionary *)dic;

@end
