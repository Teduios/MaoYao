//
//  FRAnnotation.h
//  Maoyan
//
//  Created by tarena032 on 16/2/29.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface FRAnnotation : NSObject<MKAnnotation>
@property (nonatomic ,assign) CLLocationCoordinate2D coordinate;
@property (nonatomic ,copy) NSString *title;
@property (nonatomic ,copy) NSString *subtitle;
//自定义的图片属性
@property (nonatomic ,strong) UIImage *image;
@end
