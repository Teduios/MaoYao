//
//  FRAnnotation.m
//  Maoyan
//
//  Created by tarena032 on 16/2/29.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "FRAnnotation.h"

@implementation FRAnnotation

@end
