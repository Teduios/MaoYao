//
//  Theater.m
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "Theater.h"

@implementation Theater
+(Theater *)parseDailyJson:(NSDictionary *)dic
{
    Theater *theater =[[Theater alloc]init];
    theater.brd = dic[@"nm"];
    theater.sellPrice = dic[@"sellPrice"];
    theater.addr = dic[@"addr"];
    theater.brdId = dic[@"id"];
    theater.lat = dic[@"lat"];
    theater.lng = dic[@"lng"];
    theater.imax = dic[@"imax"];
    return theater;



}
@end
