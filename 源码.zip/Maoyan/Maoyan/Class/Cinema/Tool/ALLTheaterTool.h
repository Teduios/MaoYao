//
//  ALLTheaterTool.h
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ALLTheaterTool : NSObject
+(NSArray*)getAllTheaterDataWithString:(NSString*)str and:(id)respond;//获取所有电影院信息的方法

/** 获取所有电影数据*/
+(NSArray *)getAllMovieDataWithRespond:(id)respond;



@end
