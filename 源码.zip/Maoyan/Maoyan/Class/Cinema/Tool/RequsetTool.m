//
//  RequsetTool.m
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "RequsetTool.h"
#import "AFNetworking.h"

@implementation RequsetTool
+(void)getAllTheatereDataWithUrlString:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successGetBlock)success failure:(failureGetBlock)failure
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:urlStr parameters:paraDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        success(responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    
    
    
    
}
@end
