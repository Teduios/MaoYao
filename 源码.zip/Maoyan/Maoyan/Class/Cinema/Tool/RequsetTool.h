//
//  RequsetTool.h
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^successGetBlock)(id  respond);
typedef void(^failureGetBlock)(NSError *error);
@interface RequsetTool : NSObject
/**
 获得所有的电影院信息存放到一个字典中返回
 参数：传入电影院的url信息，成功返回电影院数组
 */
+ (void)getAllTheatereDataWithUrlString:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successGetBlock)success failure:(failureGetBlock)failure;
@end
