//
//  ALLTheaterTool.m
//  选电影
//
//  Created by tarena on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ALLTheaterTool.h"
#import "Theater.h"
#import "AFNetworking.h"
#import "RequsetTool.h"
#import "movieDetail.h"
@implementation ALLTheaterTool
+(NSArray *)getAllTheaterDataWithString:(NSString *)str and:(id)respond
{
    

    NSMutableArray *array = [NSMutableArray array];
    NSArray *arr = respond[@"data"][str];
    for (NSDictionary*dic in arr) {
        Theater *theater =[Theater parseDailyJson:dic];
        [array addObject:theater];
    }
    return [array copy];

}

+(NSArray*)getAllMovieDataWithRespond:(id)respond
{
    NSArray *arr = respond[@"data"][@"shows"];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in arr) {
        movieDetail *movie =[movieDetail parseDetailJson:dic];
        [array addObject:movie];
    }
    return [array copy];
}

@end
