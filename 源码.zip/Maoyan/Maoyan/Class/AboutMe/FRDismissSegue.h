//
//  FRDismissSegue.h
//  猫眼
//
//  Created by tarena012 on 16/2/23.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FRDismissSegue : UIStoryboardSegue

@end
