//
//  FRLoginViewController.m
//  猫眼
//
//  Created by tarena012 on 16/2/20.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "FRLoginViewController.h"

@interface FRLoginViewController()
@property (weak, nonatomic) IBOutlet UITextField *userNameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;


@end

@implementation FRLoginViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    UIImageView *leftView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_login"]];
    
    leftView.frame = CGRectMake(0, 0, 55, 20);
    leftView.contentMode = UIViewContentModeCenter;
    self.userNameField.leftViewMode = UITextFieldViewModeAlways;
    leftView.highlightedImage = [UIImage imageNamed:@"ic_login_highlighted"];
    self.userNameField.leftView = leftView;
    
    UIImageView *leftView2 = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"ic_login_password"]];
    leftView2.frame = CGRectMake(0, 0, 55, 20);
    leftView2.contentMode = UIViewContentModeCenter;
    self.passwordField.leftViewMode = UITextFieldViewModeAlways;
    leftView2.highlightedImage = [UIImage imageNamed:@"ic_login_password_highlighted"];
    self.passwordField.leftView = leftView2;
    
    
}

@end
