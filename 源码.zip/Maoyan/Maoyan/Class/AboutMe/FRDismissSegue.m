//
//  FRDismissSegue.m
//  猫眼
//
//  Created by tarena012 on 16/2/23.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "FRDismissSegue.h"

@implementation FRDismissSegue

- (void)perform
{
    UIViewController *sourceViewController = self.sourceViewController;
    [sourceViewController.presentingViewController dismissViewControllerAnimated:YES completion:nil];
}

@end
