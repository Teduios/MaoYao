//
//  SHAutoScrollView.h
//  Demo循环滚动
//
//  Created by tarena032 on 16/2/23.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SHScrollViewViewDelegate;

@interface SHAutoScrollView : UIView<UIScrollViewDelegate>

{
    __unsafe_unretained id <SHScrollViewViewDelegate> _delegate;
}

@property (nonatomic, assign) id <SHScrollViewViewDelegate> delegate;

@property (nonatomic, assign) NSInteger currentPage;

@property (nonatomic, strong) NSMutableArray *imageViewAry;

@property (nonatomic, readonly) UIScrollView *scrollView;

@property (nonatomic, readonly) UIPageControl *pageControl;

@property (nonatomic ,assign) NSTimeInterval timeInterval;

-(void)shouldAutoShow:(BOOL)shouldStart;
- (void)shouldAddPageControll:(BOOL)shouldAdd;
@end

@protocol SHScrollViewViewDelegate <NSObject>
@optional
- (void)didClickPage:(SHAutoScrollView *)view atIndex:(NSInteger)index;

@end

