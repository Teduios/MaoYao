//
//  UITableViewCell+BackgroundView.m
//  Maoyan
//
//  Created by tarena032 on 16/2/25.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import "UITableViewCell+BackgroundView.h"

@implementation UITableViewCell (BackgroundView)
- (void)setBackground {
    UIImageView *backgroundView = [[UIImageView alloc]initWithFrame:self.bounds];
    backgroundView.image = [UIImage imageNamed:@"cell_single"];
    self.backgroundView = backgroundView;
    UIImageView *selectedBackgroundView = [[UIImageView alloc]initWithFrame:self.bounds];
    selectedBackgroundView.image = [UIImage imageNamed:@"cell_single_selected"];
    
    self.selectedBackgroundView = selectedBackgroundView;
}
@end
