//
//  UITableViewCell+BackgroundView.h
//  Maoyan
//
//  Created by tarena032 on 16/2/25.
//  Copyright © 2016年 Sherry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (BackgroundView)
- (void)setBackground;
@end
